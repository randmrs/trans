# P4Runtime Client
This is a pure API and multi-switch version of the [p4runtime-shell](https://github.com/p4lang/p4runtime-shell) repository.
